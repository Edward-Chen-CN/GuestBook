<?php

// web/index.php
require_once __DIR__.'/vendor/autoload.php';


$app = new Silex\Application([
	
	'debug' => true

]);

$app->register(new Silex\Provider\DoctrineServiceProvider, [
	'db.options' => [
		'driver' => 'pdo_mysql',
		'host' => 'localhost',
		'dbname' => 'guestbook_DB',
		'user' => 'user',
		'password' => '1234',
		'charset' => 'utf8mb4',

	]

]);


