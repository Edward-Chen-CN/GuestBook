<?php

// web/index.php
require_once __DIR__.'/../vendor/autoload.php';

$app = new Silex\Application([
	
	'debug' => true

]);

$app->register(new Silex\Provider\DoctrineServiceProvider, [
	'db.options' => [
		'driver' => 'pdo_mysql',
		'host' => 'localhost',
		'dbname' => 'guestbook_DB',
		'user' => 'user',
		'password' => '1234',
		'charset' => 'utf8mb4',
	]
]);

$app->get('/blog/{id}', function ($id) use ($app) {
    $sql = "SELECT * FROM guestList WHERE id = ?";

    $post = $app['db']->fetchAssoc($sql, array((int) $id));
    echo $post;
    return  "<h1>{$post['name']}</h1>".
            "<p>{$post['email']}</p>";
});

$app->get('/', function () use ($app) {
    $sql = "SELECT name, email, address, message, captcha, browser, version, platform, ip FROM guestList";

    $post = $app['db']->fetchAll($sql, array());

    foreach ($post as $key => $row) {
	    $name[$key]  = $row['name'];
	    $email[$key] = $row['email'];
	    $address[$key]  = $row['address'];
	    $message[$key] = $row['message'];
	    $captcha[$key]  = $row['captcha'];
	    $browser[$key] = $row['browser'];
	    $version[$key] = $row['version'];
	    $platform[$key] = $row['platform'];
	    $ip[$key] = $row['ip'];
	}

	echo "<table>";
	foreach($post as $key=>$row) {
	    echo "<tr>";
	    foreach($row as $key2=>$row2){
	        echo "<td>" . $row2 . "</td>";
	    }
	    echo "</tr>";
	}
	echo "</table>";


    return  "<table>{foreach($post as $key=>$row) {
			    <tr>
			    foreach($row as $key2=>$row2){
			        <td>. $row2 . </td>
			    }
			    </tr>
			}}</table>";
});

$app->run();

?>