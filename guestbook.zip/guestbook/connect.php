<?php

// $user = 'user';
// $pass = '123456';
// $db = 'guestbook_DB';

// $db = new mysqli('localhost', $user, $pass, $db) or die("failed");

// echo"hello";

$app->get('/blog/{id}', function ($id) use ($app) {
    $sql = "SELECT * FROM guestList WHERE id = ?";
    $post = $app['db']->fetchAssoc($sql, array((int) $id));

    return  "<h1>{$post['name']}</h1>".
            "<p>{$post['email']}</p>";
});

?>