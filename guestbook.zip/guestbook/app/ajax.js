function getData(dataSource, divID, name, email, address, message, captcha)  {
	var place = document.getElementById(divID);
	var text = "";
	
	var xhttp = false;  
	if (window.XMLHttpRequest) {
	    xhttp = new XMLHttpRequest();
	}
	else if (window.ActiveXObject) {
	    xhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}

	//check input
	var check = true;
	if(name == ''){
		check = false;
		text += "customer name can't be empty</br>";
		place.innerHTML = text;
	}
	
	if(check){
		if(xhttp) {
			var requestbody ="guestName="+encodeURIComponent(name)+"&email="+encodeURIComponent(email)+"&address="+encodeURIComponent(address)+"&message="+encodeURIComponent(message)+"&captcha="+encodeURIComponent(captcha);
			
			xhttp.onreadystatechange = function() {
				
				if (this.readyState == 4 && this.status == 200) {
					place.innerHTML = this.responseText;
				} // end if
			}; // end anonymous call-back function
			
			xhttp.open("POST", dataSource, true);
			xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			alert("succeed");
			xhttp.send(requestbody);
		} // end if
	}// end if
	document.getElementById('guestForm').reset(); //clear form
} // end function getData()