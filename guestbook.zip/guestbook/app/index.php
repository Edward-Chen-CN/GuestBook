<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<script type="text/javascript" src="ajax.js"></script>	
		<script src='https://www.google.com/recaptcha/api.js'></script>	
		<link rel="stylesheet" type="text/css" href="../bower_components/bootstrap/dist/css/bootstrap.min.css">
		<script src="../bower_components/jquery/dist/jquery.min.js"></script>
		<script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
		<script type="text/javascript" src='./pagination.js'></script>
		<title>Guest Book</title>
	</head>
	<body style="text-align: center;">

		<header>
			<h1>Guest Book</h1>
		</header>
		<div id="container" style="padding: 0 30px;">
			<form id="guestForm">
				<div class="form-group">
					<label>Guest Name</label>
					<div class="txtField">
						<input type="text" class="form-control" id="guestName" name="guestName" />
					</div>
				</div>
				<div class="form-group">
					<label>Email</label>
					<div class="txtField">
						<input type="text" class="form-control" id="email" name="email" />
					</div>
				</div>
				<div class="form-group">
					<label>address</label>
					<div class="txtField">
						<input type="text" class="form-control" id="address" name="address" />
					</div>
				</div>
				<div class="form-group">
					<label>message</label>
					<div class="txtField">
						<input type="text" class="form-control" id="message" name="message" />
					</div>
				</div>

				<div class="form-group">
					<label>captcha</label>
					<div class="txtField">
						<input type="text" class="form-control" id="captcha" name="captcha" />
					</div>
				</div>


				<div class="form-group">
					<div></div>
					<div class="txtField">
						<input class="btn btn-success" name="submit" type = "button" onClick = "getData('process.php','targetDiv', guestName.value, email.value, address.value, message.value, captcha.value) " value = "request">
						<input class="btn btn-danger" type="reset" value="Reset" />
					</div>
				</div>
				<div class="g-recaptcha" data-sitekey="6Le6eyUUAAAAAH5ecbQIyXs5eChL69JiLPILxIC2" style="display: inline-block;"></div>
			</form>
		
			<div id="targetDiv" style="display: inline-block;">
				<?php 
					require_once __DIR__.'/../vendor/autoload.php';
					use JasonGrimes\Paginator;
					require_once ("settings.php");
					//connection
					$conn = @mysqli_connect($host,
							$user,
							$pswd,
							$dbnm
							);
					//Checks if connection is successful
					if (!$conn) {
				        // Displays an error message
				        echo "<p>Database connection failure</p>";
				    } 
				    else {
				        // Upon successful connection
						// Set up the SQL command to add the data into the table

						$query = "select name, email, address, message, captcha, browser, version, platform, ip from guestList order by id DESC;";
						// executes the query and store result into the result pointer

						$result = mysqli_query($conn, $query) or die(mysqli_error());

						// checks if the execuion was successful
					    if(!$result) {
					        echo "<p>Something is wrong with ",	$query, "</p>";
					    } 
					    else {

					    // Display the retrieved records
							echo "succeed";
					        echo "<table class=\"table table-striped table-hover table-condensed table-bordered\" id=\"Tabla\"  style=\"text-align: left;\">";
					        echo "<tbody>\n";
					        echo "<tr>\n"
					        ."<th scope=\"col\">name</th>\n"
					        ."<th scope=\"col\">email</th>\n"
					        ."<th scope=\"col\">address</th>\n"
					        ."<th scope=\"col\">message</th>\n"
					        ."<th scope=\"col\">browser</th>\n"
					        ."<th scope=\"col\">version</th>\n"
					        ."<th scope=\"col\">platform</th>\n"
					        ."<th scope=\"col\">ip</th>\n"
					        ."<th scope=\"col\">captcha</th>\n"

					        ."</tr>\n";
					        // retrieve current record pointed by the result pointer
					        while ($row = mysqli_fetch_assoc($result)){
					            echo "<tr>";
					            echo "<td>",$row["name"],"</td>";
					            echo "<td>",$row["email"],"</td>";
					            echo "<td>",$row["address"],"</td>";
					            echo "<td>",$row["message"],"</td>";
					            echo "<td>",$row["browser"],"</td>";
					            echo "<td>",$row["version"],"</td>";
					            echo "<td>",$row["platform"],"</td>";
				            	echo "<td>",$row["ip"],"</td>";
					            echo "<td>",$row["captcha"],"</td>";

					            echo "</tr>";
					        }
					        echo "</tbody>";
					    	echo "</table>";
					        // Frees up the memory, after using the result pointer
					        mysqli_free_result($result);
					    } // if successful query operation

					    // close the database connection
					    mysqli_close($conn);

				    } 
				    echo "<ul class=\"pagination\"></ul>"

				?>
			</div>
		</div>

	</body>
</html>