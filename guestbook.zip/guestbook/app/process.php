<?php 

	require_once __DIR__.'/../vendor/autoload.php';

	use Sinergi\BrowserDetector\Browser;
	use Sinergi\BrowserDetector\Os;
	use JasonGrimes\Paginator;

	$os = new Os();
	$os->getName();
	$browser = new Browser();
	$browserName = $browser->getName();
	$browserVersion = $browser->getVersion();
	$userOS = $os->getName();

	function getUserIP() {
	    $client  = @$_SERVER['HTTP_CLIENT_IP'];
	    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
	    $remote  = $_SERVER['REMOTE_ADDR'];

	    if(filter_var($client, FILTER_VALIDATE_IP)) {
	        $ip = $client;
	    }
	    elseif(filter_var($forward, FILTER_VALIDATE_IP)) {
	        $ip = $forward;
	    }
	    else {
	        $ip = $remote;
	    }

	    return $ip;
	}

	$user_ip = getUserIP();

	// Get data from the form
	$name		=	$_POST['guestName'];
	$email		=	$_POST["email"];
	$address	=	$_POST["address"];
	$message	=	$_POST["message"];
	$browser	=	$browserName;
	$version	=	$browserVersion;
	$platform	=	$userOS;
	$ip			=	$user_ip;
	$captcha	=	$_POST["captcha"];

	
	require_once ("settings.php");
	//connection
	$conn = @mysqli_connect($host,
			$user,
			$pswd,
			$dbnm
			);
	//Checks if connection is successful
	if (!$conn) {
        // Displays an error message
        echo "<p>Database connection failure</p>";
    } 
    else {
        // Upon successful connection

    	$result = mysqli_query($conn,"select id from guestList") or die(mysqli_error()); 

    	$totalItems = mysqli_num_rows($result);

		$itemsPerPage = 10;
		$currentPage = 1;

		
		$totalPage = ceil($totalItems/$itemsPerPage); 
		
		$startPage = ($currentPage-1)*$itemsPerPage; 

		$urlPattern = 'javascript:void(0)';

		$paginator = new Paginator($totalItems, $itemsPerPage, $currentPage, $urlPattern);
		
		// Set up the SQL command to add the data into the table

		$query = "insert into guestList"."(name, email, address, message, browser, version, platform, ip, captcha)". "values"."('$name','$email','$address','$message','$browser','$version','$platform','$ip','$captcha')";
		$query1 = "select name, email, address, message, captcha, browser, version, platform, ip from guestList order by id DESC limit $startPage, $itemsPerPage;";
		// executes the query and store result into the result pointer
		$result = mysqli_query($conn, $query) or die(mysqli_error());
		$result = mysqli_query($conn, $query1) or die(mysqli_error());

		// checks if the execuion was successful
	    if(!$result) {
	        echo "<p>Something is wrong with ",	$query, "</p>";
	    } 
	    else {

	    // Display the retrieved records
			echo "succeed";
			echo "<script type=\"text/javascript\" src='./pagination.js'></script>";
	        echo "<table class=\"table table-striped table-hover table-condensed table-bordered\" id=\"Tabla\"  style=\"text-align: left;\">";
	        echo "<tbody>\n";
	        echo "<tr>\n"
	        ."<th scope=\"col\">name</th>\n"
	        ."<th scope=\"col\">email</th>\n"
	        ."<th scope=\"col\">address</th>\n"
	        ."<th scope=\"col\">message</th>\n"
	        ."<th scope=\"col\">browser</th>\n"
	        ."<th scope=\"col\">version</th>\n"
	        ."<th scope=\"col\">platform</th>\n"
	        ."<th scope=\"col\">ip</th>\n"
	        ."<th scope=\"col\">captcha</th>\n"

	        ."</tr>\n";
	        // retrieve current record pointed by the result pointer
	        // Note the = is used to assign the record value to variable $row, this is not an error
	        // the ($row = mysqli_fetch_assoc($result)) operation results to false if no record was retrieved
	        // _assoc is used instead of _row, so field name can be used
	        while ($row = mysqli_fetch_assoc($result)){
	            echo "<tr>";
	            echo "<td>",$row["name"],"</td>";
	            echo "<td>",$row["email"],"</td>";
	            echo "<td>",$row["address"],"</td>";
	            echo "<td>",$row["message"],"</td>";
	            echo "<td>",$row["browser"],"</td>";
	            echo "<td>",$row["version"],"</td>";
	            echo "<td>",$row["platform"],"</td>";
            	echo "<td>",$row["ip"],"</td>";
	            echo "<td>",$row["captcha"],"</td>";

	            echo "</tr>";
	        }
	        echo "</tbody>";
	    	echo "</table>";

	    	echo $paginator;
	        // Frees up the memory, after using the result pointer
	        mysqli_free_result($result);
	    } // if successful query operation

	    // close the database connection
	    mysqli_close($conn);

    } 

?>