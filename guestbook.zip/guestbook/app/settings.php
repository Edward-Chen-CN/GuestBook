<?php
	$host = "localhost";
	$user = "user";
	$pswd = "1234";
	$dbnm = "guestbook_DB";
?>